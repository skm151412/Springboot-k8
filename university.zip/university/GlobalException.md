**Introduction to Exception Handling in REST APIs**
In a REST API, exceptions can occur due to:
•	Invalid input data
•	Resource not found
•	Database errors
•	Type mismatch
•	Server errors
**If exceptions are not handled properly, Spring Boot returns:**
•	 Technical stack trace
•	 White Label Error page
•	 Poor user experience
**To solve this:**
**Global Exception Handling**
**Using:**
•	@ControllerAdvice
•	@ExceptionHandler

**2️ @ControllerAdvice**

@ControllerAdvice is a Spring annotation that allows:
•	Centralized exception handling
•	Applies to all controllers
•	Separates error handling logic from business logic
Instead of writing try-catch in every controller, we handle exceptions in one place.

**3️Exception Flow in Spring Boot**
 Without Global Exception Handling
Client → Controller → Exception → Spring Default Handler → White Label Error
With @ControllerAdvice
Client → Controller → Exception → @ControllerAdvice → Custom JSON Response

**4️ Key Components **
To implement global exception handling, we need:
1.	Custom Exception Class
2.	REST Controller
3.	Error Response Model
4.	Global Exception Handler (@ControllerAdvice)

**Example: University Student REST API**
Scenario:
When a user enters:
•	Invalid student ID → return user-friendly error
•	Invalid format → return readable error message

 **Step 1: Create Custom Exception**
StudentNotFoundException.java
package com.example.demo.exception;

public class StudentNotFoundException extends RuntimeException {

    public StudentNotFoundException(String message) {
        super(message);
    }
}
✔ Extends RuntimeException
✔ Used when student ID does not exist

**Step 3: Create Another Custom Exception**
InvalidInputException.java
package com.example.demo.exception;

public class InvalidInputException extends RuntimeException {

    public InvalidInputException(String message) {
        super(message);
    }
}
✔ Used when input format is invalid

**Step 4: Create Error Response Model**
This ensures consistent structured JSON output.
ErrorResponse.java
package com.example.demo.exception;

import java.time.LocalDateTime;

public class ErrorResponse {

    private LocalDateTime timestamp;
    private String message;
    private int statusCode;

    public ErrorResponse(LocalDateTime timestamp, String message, int statusCode) {
        this.timestamp = timestamp;
        this.message = message;
        this.statusCode = statusCode;
    }

    public LocalDateTime getTimestamp() { return timestamp; }
    public String getMessage() { return message; }
    public int getStatusCode() { return statusCode; }
}

 **Step 5: Create REST Controller**
StudentController.java
package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import com.example.demo.exception.*;

@RestController
@RequestMapping("/student")
public class StudentController {

    @GetMapping("/{id}")
    public String getStudent(@PathVariable String id) {

        int studentId;

        try {
            studentId = Integer.parseInt(id);
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Student ID must be a number.");
        }

        if (studentId != 1) {
            throw new StudentNotFoundException("Student with ID " + studentId + " not found.");
        }

        return "Student Found: John Doe";
    }
}

**6️ Create Global Exception Handler**
GlobalExceptionHandler.java
package com.example.demo.exception;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(StudentNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleStudentNotFound(
            StudentNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                ex.getMessage(),
                HttpStatus.NOT_FOUND.value()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(InvalidInputException.class)
    public ResponseEntity<ErrorResponse> handleInvalidInput(
            InvalidInputException ex) {

        ErrorResponse error = new ErrorResponse(
                LocalDateTime.now(),
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value()
        );

        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }
}

**7️ How It Works Internally**
When /student/2 is called:
1.	Controller executes
2.	StudentNotFoundException is thrown
3.	Spring scans for @ControllerAdvice
4.	Finds matching @ExceptionHandler
5.	Returns structured JSON response

**8️ Sample API Testing**
 Valid Request
GET /student/1
Response:
Student Found: John Doe

 Student Not Found
GET /student/5
Response:
{
  "timestamp": "2026-02-18T14:00:00",
  "message": "Student with ID 5 not found.",
  "statusCode": 404
}

 Invalid Input
GET /student/abc
Response:
{
  "timestamp": "2026-02-18T14:02:00",
  "message": "Student ID must be a number.",
  "statusCode": 400
}

**9️ Advantages of @ControllerAdvice**
✔ Centralized error handling
✔ Cleaner controllers
✔ Reusable across application
✔ User-friendly responses
✔ Better API design
✔ Easy maintenance

**10 Difference Between Local and Global Exception Handling**
Local Handling	Global Handling
try-catch inside controller	@ControllerAdvice
Code duplication	Centralized
Hard to maintain	Easy to maintain

**11Best Practices**
•	Always return structured JSON
•	Use meaningful HTTP status codes
•	Do not expose stack traces
•	Create custom exceptions for business logic
•	Keep controller clean
**1️2 Conclusion**
@ControllerAdvice allows us to:
•	Handle exceptions globally
•	Improve API usability
•	Provide consistent error responses
•	Separate error handling from business logic
It is an essential feature in building production-ready REST APIs using Spring Boot.
