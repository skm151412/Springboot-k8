package com.example.demo.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entity.Book;

public interface BookRepository extends JpaRepository<Book,Long>{

    List<Book> findByCategory(String category);

    List<Book> findByPriceBetween(double min,double max);

    @Query("SELECT b FROM Book b ORDER BY b.price ASC")
    List<Book> sortBooks();

    @Query("SELECT b FROM Book b WHERE b.price>?1")
    List<Book> expensiveBooks(double price);

    @Query("SELECT b FROM Book b WHERE b.author=?1")
    List<Book> findByAuthor(String author);
}