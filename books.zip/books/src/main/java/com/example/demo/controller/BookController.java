package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Book;
import com.example.demo.repository.BookRepository;

@RestController
public class BookController {

    @Autowired
    BookRepository repo;

    @PostMapping("/books")
    public Book addBook(@RequestBody Book b){
        return repo.save(b);
    }

    @GetMapping("/books/category/{category}")
    public List<Book> getByCategory(@PathVariable String category){
        return repo.findByCategory(category);
    }

    @GetMapping("/books/filter")
    public List<Book> filter(@RequestParam double min,@RequestParam double max){
        return repo.findByPriceBetween(min,max);
    }

    @GetMapping("/books/sorted")
    public List<Book> sorted(){
        return repo.sortBooks();
    }

    @GetMapping("/books/expensive/{price}")
    public List<Book> expensive(@PathVariable double price){
        return repo.expensiveBooks(price);
    }
}